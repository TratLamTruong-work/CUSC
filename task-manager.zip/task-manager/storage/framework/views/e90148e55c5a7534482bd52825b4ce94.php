<?php $__env->startSection('title', 'Danh sách công việc'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <h1 class="h3 mb-0">Danh sách công việc</h1>
    <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-primary">Thêm công việc</a>
</div>


<div class="row row-cols-2 row-cols-md-4 g-3 mb-2">
    <div class="col"><div class="stat-box"><div class="text-muted">Tổng công việc</div><div class="stat-number"><?php echo e($stats['total']); ?></div></div></div>
    <div class="col"><div class="stat-box"><div class="text-muted">Chưa làm</div><div class="stat-number"><?php echo e($stats['pending']); ?></div></div></div>
    <div class="col"><div class="stat-box"><div class="text-muted">Đang làm</div><div class="stat-number text-primary"><?php echo e($stats['in_progress']); ?></div></div></div>
    <div class="col"><div class="stat-box"><div class="text-muted">Hoàn thành</div><div class="stat-number text-success"><?php echo e($stats['completed']); ?></div></div></div>
</div>
<p class="text-muted small mb-3">
    <?php if($isAdmin): ?>
        Số liệu tính trên tất cả công việc trong hệ thống, không thay đổi theo bộ lọc bên dưới.
    <?php else: ?>
        Số liệu tính trên tất cả công việc của bạn, không thay đổi theo bộ lọc bên dưới.
    <?php endif; ?>
</p>

<form method="GET" action="<?php echo e(route('tasks.index')); ?>" class="panel">
    <div class="row g-3 align-items-end">
        <div class="col-12 col-lg-4">
            <label for="keyword" class="form-label">Từ khóa</label>
            <input type="search" id="keyword" name="keyword" value="<?php echo e($filters['keyword']); ?>" maxlength="255"
                   class="form-control" placeholder="Tên hoặc mô tả công việc">
        </div>
        <div class="col-6 col-lg-2">
            <label for="status" class="form-label">Trạng thái</label>
            <select id="status" name="status" class="form-select">
                <option value="">Tất cả</option>
                <?php $__currentLoopData = \App\Models\Task::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php if($filters['status'] === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-6 col-lg-2">
            <label for="priority" class="form-label">Ưu tiên</label>
            <select id="priority" name="priority" class="form-select">
                <option value="">Tất cả</option>
                <?php $__currentLoopData = \App\Models\Task::PRIORITIES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php if($filters['priority'] === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <?php if($isAdmin): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <label for="owner" class="form-label">Người sở hữu</label>
                <select id="owner" name="owner" class="form-select">
                    <option value="">Tất cả người dùng</option>
                    <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($owner->id); ?>" <?php if($filters['owner'] === $owner->id): echo 'selected'; endif; ?>><?php echo e($owner->username); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        <?php endif; ?>
        <div class="col-12 col-md-6 col-lg-4">
            <label for="sort" class="form-label">Sắp xếp</label>
            <select id="sort" name="sort" class="form-select">
                <option value="newest" <?php if($filters['sort'] === 'newest'): echo 'selected'; endif; ?>>Mới nhất</option>
                <option value="due" <?php if($filters['sort'] === 'due'): echo 'selected'; endif; ?>>Hạn chót gần nhất</option>
            </select>
        </div>
        <div class="col-12 d-flex flex-wrap gap-2">
            <button type="submit" class="btn btn-primary">Tìm kiếm</button>
            <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-outline-secondary">Xóa bộ lọc</a>
        </div>
    </div>
</form>

<div class="panel p-0 overflow-hidden">
    <?php if($tasks->isEmpty()): ?>
        <div class="text-center p-5">
            <?php if($stats['total'] === 0): ?>
                <p class="fs-5 mb-3"><?php echo e($isAdmin ? 'Hệ thống chưa có công việc nào' : 'Bạn chưa có công việc nào'); ?></p>
                <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-primary">Thêm công việc</a>
            <?php else: ?>
                <p class="fs-5 mb-3">Không tìm thấy công việc phù hợp</p>
                <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-outline-primary">Xóa bộ lọc</a>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                <tr>
                    <th scope="col">STT</th>
                    <th scope="col">Tên công việc</th>
                    <?php if($isAdmin): ?>
                        <th scope="col">Người sở hữu</th>
                    <?php endif; ?>
                    <th scope="col">Ngày bắt đầu</th>
                    <th scope="col">Hạn chót</th>
                    <th scope="col">Ưu tiên</th>
                    <th scope="col">Trạng thái</th>
                    <th scope="col">Thao tác</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($tasks->firstItem() + $loop->index); ?></td>
                        <td class="task-title">
                            <a href="<?php echo e(route('tasks.show', $task->id)); ?>" class="fw-semibold text-decoration-none"
                               title="<?php echo e($task->title); ?>"><?php echo e(\Illuminate\Support\Str::limit($task->title, 100)); ?></a>
                        </td>
                        <?php if($isAdmin): ?>
                            <td class="text-nowrap"><?php echo e($task->user->username); ?></td>
                        <?php endif; ?>
                        <td class="text-nowrap"><?php echo e($task->start_date->format('d/m/Y')); ?></td>
                        <td class="text-nowrap">
                            <?php echo e($task->due_date->format('d/m/Y')); ?>

                            
                            <?php if($task->isOverdue()): ?>
                                <span class="badge badge-overdue ms-1">Quá hạn</span>
                            <?php endif; ?>
                        </td>
                        <td><span class="badge <?php echo e($task->priorityBadgeClass()); ?>"><?php echo e($task->priorityLabel()); ?></span></td>
                        <td>
                            <span class="badge <?php echo e($task->statusBadgeClass()); ?>"><?php echo e($task->statusLabel()); ?></span>
                            <form method="POST" action="<?php echo e(route('tasks.status', $task->id)); ?>" class="d-flex gap-1 mt-1">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <label for="status-<?php echo e($task->id); ?>" class="visually-hidden">Đổi trạng thái công việc số <?php echo e($tasks->firstItem() + $loop->index); ?></label>
                                <select id="status-<?php echo e($task->id); ?>" name="status" class="form-select form-select-sm status-select">
                                    <?php $__currentLoopData = \App\Models\Task::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value); ?>" <?php if($task->status === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="btn btn-sm btn-outline-primary">Lưu</button>
                            </form>
                        </td>
                        <td>
                            <div class="d-flex flex-wrap gap-1">
                                <a href="<?php echo e(route('tasks.show', $task->id)); ?>" class="btn btn-sm btn-outline-secondary">Xem</a>
                                <a href="<?php echo e(route('tasks.edit', $task->id)); ?>" class="btn btn-sm btn-outline-primary">Sửa</a>
                                <form method="POST" action="<?php echo e(route('tasks.destroy', $task->id)); ?>" class="m-0"
                                      data-confirm="Bạn có chắc muốn xóa công việc này? Hành động không thể hoàn tác.">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">Xóa</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 p-3 border-top">
            <span>Tìm thấy <strong><?php echo e($tasks->total()); ?></strong> công việc</span>
            <?php echo e($tasks->links('pagination')); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Test_PV_PHP_CUSC\task-manager\resources\views/tasks/index.blade.php ENDPATH**/ ?>