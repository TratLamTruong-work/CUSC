<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        // Người chưa đăng nhập -> /login, người đã đăng nhập vào trang khách -> /tasks
        $middleware->redirectGuestsTo('/login');
        $middleware->redirectUsersTo('/tasks');
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
